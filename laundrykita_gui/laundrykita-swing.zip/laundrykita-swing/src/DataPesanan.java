import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Penyimpanan data pesanan sementara (di memori) yang dipakai bersama oleh
 * halaman Pesanan dan halaman Pesanan Baru. Data hilang saat aplikasi ditutup.
 */
public class DataPesanan {

    public static final String[] DAFTAR_STATUS = {"Menunggu", "Diproses", "Dicuci", "Disetrika", "Selesai"};
    public static final String[] LAYANAN = {"Cuci Kering", "Cuci Setrika", "Setrika Saja"};
    private static final long[] HARGA_PER_KG = {7000, 10000, 6000};

    private static final List<Pesanan> daftar = new ArrayList<>();
    private static int nomorBerikut = 1;

    // Data awal, sama dengan contoh di halaman admin-pesanan.html
    static {
        tambah("Salwa", "", "Cuci Kering", 3, "Jl. Contoh No. 10, Pekanbaru", "", "", "Selesai");
        tambah("Salwa", "", "Setrika Saja", 2, "Jl. Contoh No. 10, Pekanbaru", "", "", "Selesai");
        tambah("Salwa", "", "Cuci Setrika", 3, "Jl. Contoh No. 10, Pekanbaru", "", "", "Diproses");
        tambah("Aulia", "", "Cuci Kering", 3, "Jl. Merdeka No. 5, Pekanbaru", "", "", "Dicuci");
        tambah("Rina", "", "Setrika Saja", 2, "Jl. Sudirman No. 12, Pekanbaru", "", "", "Selesai");
        tambah("Dinda", "", "Cuci Setrika", 4, "Jl. Ahmad Yani No. 8, Pekanbaru", "", "", "Menunggu");
    }

    private DataPesanan() { }

    public static List<Pesanan> semua() {
        return daftar;
    }

    public static Pesanan tambah(String nama, String noHp, String layanan, double berat,
                                 String alamat, String catatan, String estimasi, String status) {
        String id = String.format("#LK%03d", nomorBerikut++);
        Pesanan p = new Pesanan(id, nama, noHp, layanan, berat, hitungTotal(layanan, berat),
                alamat, catatan, estimasi, status);
        daftar.add(p);
        return p;
    }

    /** Nama pelanggan yang sudah pernah memesan (tanpa duplikat). */
    public static List<String> daftarPelanggan() {
        Set<String> nama = new LinkedHashSet<>();
        for (Pesanan p : daftar) {
            nama.add(p.getNama());
        }
        return new ArrayList<>(nama);
    }

    public static long hargaPerKg(String layanan) {
        for (int i = 0; i < LAYANAN.length; i++) {
            if (LAYANAN[i].equals(layanan)) {
                return HARGA_PER_KG[i];
            }
        }
        return 0;
    }

    public static long hitungTotal(String layanan, double berat) {
        return Math.round(hargaPerKg(layanan) * berat);
    }

    public static String formatRupiah(long jumlah) {
        NumberFormat nf = NumberFormat.getIntegerInstance(Locale.forLanguageTag("id-ID"));
        return "Rp" + nf.format(jumlah);
    }

    public static String formatBerat(double berat) {
        return BigDecimal.valueOf(berat).stripTrailingZeros().toPlainString();
    }
}
