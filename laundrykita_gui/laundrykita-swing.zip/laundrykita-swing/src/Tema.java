import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.util.Collections;

/**
 * Warna, font, dan fungsi bantu tampilan yang dipakai semua halaman
 * (mengikuti tema biru-kuning dari CSS/style.css).
 */
public class Tema {

    public static final Color BIRU = new Color(0x15, 0x57, 0xB0);
    public static final Color KUNING = new Color(0xF0, 0xC9, 0x28);
    public static final Color LATAR = new Color(0xF5, 0xF8, 0xFC);
    public static final Color TEKS = new Color(0x33, 0x33, 0x33);
    public static final Color TEKS_PUDAR = new Color(0x6C, 0x75, 0x7D);
    public static final Color ABU = new Color(0x6C, 0x75, 0x7D);
    public static final Color GARIS = new Color(0xDE, 0xE2, 0xE6);
    public static final Color GARIS_INPUT = new Color(0xCE, 0xD4, 0xDA);
    public static final Color MERAH = new Color(0xDC, 0x35, 0x45);

    public static final Font FONT = new Font(Font.SANS_SERIF, Font.PLAIN, 14);
    public static final Font FONT_TEBAL = FONT.deriveFont(Font.BOLD);
    public static final Font FONT_KECIL = FONT.deriveFont(12f);
    public static final Font FONT_JUDUL = FONT.deriveFont(Font.BOLD, 26f);

    private static final int TINGGI_INPUT = 36;

    private Tema() { }

    /** Samakan font semua komponen Swing. Panggil sekali sebelum membuat jendela. */
    public static void pasangTampilan() {
        for (Object kunci : Collections.list(UIManager.getDefaults().keys())) {
            if (kunci instanceof String && ((String) kunci).toLowerCase().endsWith("font")) {
                UIManager.put(kunci, new FontUIResource(FONT));
            }
        }
        // combo box yang sedang fokus: biru muda, bukan abu-biru bawaan Metal
        UIManager.put("ComboBox.selectionBackground", new Color(0xE8, 0xF0, 0xFB));
        UIManager.put("ComboBox.selectionForeground", TEKS);
    }

    // ---------- warna status (badge) ----------

    public static Color warnaStatus(String status) {
        switch (status) {
            case "Diproses":  return new Color(0x0D, 0x6E, 0xFD);
            case "Dicuci":
            case "Disetrika": return new Color(0xFF, 0xC1, 0x07);
            case "Selesai":   return new Color(0x19, 0x87, 0x54);
            default:          return new Color(0x6C, 0x75, 0x7D); // Menunggu
        }
    }

    public static Color warnaTeksStatus(String status) {
        return (status.equals("Dicuci") || status.equals("Disetrika")) ? Color.BLACK : Color.WHITE;
    }

    // ---------- komponen ----------

    public static JButton tombol(String teks, Color latar, Color huruf) {
        JButton b = new JButton(teks);
        b.setFont(FONT);
        b.setBackground(latar);
        b.setForeground(huruf);
        b.setOpaque(true);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 16, 8, 16));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JLabel label(String teks) {
        JLabel l = new JLabel(teks);
        l.setFont(FONT_TEBAL);
        l.setForeground(TEKS);
        return l;
    }

    /** Label pesan kesalahan (merah, awalnya disembunyikan). */
    public static JLabel error(String teks) {
        JLabel l = new JLabel(teks);
        l.setFont(FONT_KECIL);
        l.setForeground(MERAH);
        l.setVisible(false);
        return l;
    }

    public static JLabel footer() {
        JLabel l = new JLabel("\u00A9 2026 LaundryKita \u2014 Sistem Pemesanan Laundry", SwingConstants.CENTER);
        l.setOpaque(true);
        l.setBackground(Color.WHITE);
        l.setForeground(TEKS_PUDAR);
        l.setBorder(new EmptyBorder(16, 0, 16, 0));
        return l;
    }

    public static void gayaKartu(JPanel panel, int padding) {
        panel.setBackground(Color.WHITE);
        panel.setBorder(new CompoundBorder(new LineBorder(GARIS),
                new EmptyBorder(padding, padding, padding, padding)));
    }

    public static JPanel kartu(LayoutManager layout, int padding) {
        JPanel panel = new JPanel(layout);
        gayaKartu(panel, padding);
        return panel;
    }

    public static void gayaField(JTextField field) {
        field.setFont(FONT);
        field.setPreferredSize(new Dimension(100, TINGGI_INPUT));
        tandai(field, false);
    }

    public static void gayaCombo(JComboBox<String> combo) {
        combo.setFont(FONT);
        combo.setBackground(Color.WHITE);
        combo.setPreferredSize(new Dimension(combo.getPreferredSize().width, TINGGI_INPUT));
        tandai(combo, false);
    }

    /** Bungkus JTextArea dengan scroll pane bergaya input. */
    public static JScrollPane areaTeks(JTextArea area) {
        area.setFont(FONT);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(new EmptyBorder(7, 10, 7, 10));
        JScrollPane sp = new JScrollPane(area);
        tandai(sp, false);
        return sp;
    }

    /** Beri border merah (salah) atau abu-abu (normal) pada komponen input. */
    public static void tandai(JComponent c, boolean salah) {
        Color warna = salah ? MERAH : GARIS_INPUT;
        if (c instanceof JTextField) {
            c.setBorder(new CompoundBorder(new LineBorder(warna), new EmptyBorder(7, 10, 7, 10)));
        } else {
            c.setBorder(new LineBorder(warna));
        }
    }

    /** Tampilkan/sembunyikan komponen lalu susun ulang tata letak induknya. */
    public static void tampilkan(JComponent c, boolean tampil) {
        c.setVisible(tampil);
        Container induk = c.getParent();
        if (induk != null) {
            induk.revalidate();
            induk.repaint();
        }
    }

    /** Jalankan aksi setiap isi kolom teks berubah. */
    public static void saatBerubah(JTextComponent teks, Runnable aksi) {
        teks.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { aksi.run(); }
            @Override public void removeUpdate(DocumentEvent e) { aksi.run(); }
            @Override public void changedUpdate(DocumentEvent e) { aksi.run(); }
        });
    }
}
