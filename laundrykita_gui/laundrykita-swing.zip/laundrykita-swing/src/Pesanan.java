/**
 * Model data untuk satu pesanan laundry.
 */
public class Pesanan {

    private final String id;
    private final String nama;
    private final String noHp;
    private final String layanan;
    private final double berat;
    private final long total;
    private final String alamat;
    private final String catatan;
    private final String estimasi;
    private String status;

    public Pesanan(String id, String nama, String noHp, String layanan, double berat,
                   long total, String alamat, String catatan, String estimasi, String status) {
        this.id = id;
        this.nama = nama;
        this.noHp = noHp;
        this.layanan = layanan;
        this.berat = berat;
        this.total = total;
        this.alamat = alamat;
        this.catatan = catatan;
        this.estimasi = estimasi;
        this.status = status;
    }

    public String getId() { return id; }
    public String getNama() { return nama; }
    public String getNoHp() { return noHp; }
    public String getLayanan() { return layanan; }
    public double getBerat() { return berat; }
    public long getTotal() { return total; }
    public String getAlamat() { return alamat; }
    public String getCatatan() { return catatan; }
    public String getEstimasi() { return estimasi; }
    public String getStatus() { return status; }

    public void setStatus(String status) { this.status = status; }

    /** Contoh: "3 Kg" atau "2.5 Kg". */
    public String getBeratTeks() {
        return DataPesanan.formatBerat(berat) + " Kg";
    }

    /** Contoh: "Rp21.000". */
    public String getTotalTeks() {
        return DataPesanan.formatRupiah(total);
    }
}
