import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

/**
 * Halaman "Catat Pesanan Baru" (admin-pesanan-baru.html): form input pesanan,
 * ringkasan total otomatis, dan validasi sebelum disimpan.
 */
public class AdminPesananBaruFrame extends JFrame {

    private static final DateTimeFormatter FORMAT_TANGGAL =
            DateTimeFormatter.ofPattern("dd-MM-uuuu").withResolverStyle(ResolverStyle.STRICT);

    // input
    private final JComboBox<String> namaCombo =
            new JComboBox<>(DataPesanan.daftarPelanggan().toArray(new String[0]));
    private final JTextField hpField = new JTextField();
    private final JComboBox<String> layananCombo = new JComboBox<>();
    private final JTextField beratField = new JTextField();
    private final JTextArea alamatArea = new JTextArea(3, 20);
    private final JTextArea catatanArea = new JTextArea(3, 20);
    private final JTextField estimasiField = new JTextField();
    private final JComboBox<String> statusCombo = new JComboBox<>(DataPesanan.DAFTAR_STATUS);
    private final JScrollPane alamatScroll = Tema.areaTeks(alamatArea);
    private final JScrollPane catatanScroll = Tema.areaTeks(catatanArea);

    // pesan kesalahan
    private final JLabel errNama = Tema.error("Nama pelanggan wajib diisi.");
    private final JLabel errHp = Tema.error("Nomor HP wajib diisi.");
    private final JLabel errBerat = Tema.error("Berat harus lebih dari 0 kg.");
    private final JLabel errAlamat = Tema.error("Alamat wajib diisi.");
    private final JLabel errEstimasi = Tema.error("Format tanggal harus dd-MM-yyyy, contoh 25-10-2026.");

    // ringkasan total
    private final JLabel ringLayanan = new JLabel();
    private final JLabel ringHarga = new JLabel();
    private final JLabel ringBerat = new JLabel();
    private final JLabel ringTotal = new JLabel();

    private int baris = 0; // baris GridBag berikutnya di kartu form

    public AdminPesananBaruFrame() {
        super("LaundryKita - Catat Pesanan Baru");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 720);
        setMinimumSize(new Dimension(700, 520));
        setLocationRelativeTo(null);
        getContentPane().setBackground(Tema.LATAR);
        setLayout(new BorderLayout());

        siapkanInput();

        add(new NavbarAdmin(this, NavbarAdmin.PESANAN_BARU), BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(buatKonten());
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);
        add(Tema.footer(), BorderLayout.SOUTH);

        perbaruiRingkasan();
    }

    // ------------------------------------------------------------------
    // Susunan halaman
    // ------------------------------------------------------------------

    private JPanel buatKonten() {
        JLabel judul = new JLabel("Catat Pesanan Baru");
        judul.setFont(Tema.FONT_JUDUL);
        judul.setForeground(Tema.TEKS);
        judul.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Isi data cucian yang diterima dari pelanggan.");
        sub.setForeground(Tema.TEKS_PUDAR);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel teksJudul = new JPanel();
        teksJudul.setLayout(new BoxLayout(teksJudul, BoxLayout.Y_AXIS));
        teksJudul.setOpaque(false);
        teksJudul.add(judul);
        teksJudul.add(Box.createVerticalStrut(4));
        teksJudul.add(sub);

        JPanel isi = new JPanel(new GridBagLayout());
        isi.setBackground(Tema.LATAR);
        isi.setBorder(new EmptyBorder(32, 24, 32, 24));

        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.anchor = GridBagConstraints.NORTH; // di tengah secara horizontal, menempel ke atas

        g.gridy = 0;
        g.insets = new Insets(0, 0, 28, 0);
        isi.add(teksJudul, g);

        g.gridy = 1;
        g.weightx = 1;
        g.weighty = 1;
        g.insets = new Insets(0, 0, 0, 0);
        isi.add(buatKartuForm(), g);

        return isi;
    }

    private JPanel buatKartuForm() {
        JPanel kartu = new JPanel(new GridBagLayout()) {
            @Override
            public Dimension getPreferredSize() {
                Dimension d = super.getPreferredSize();
                d.width = 580; // lebar tetap, tinggi mengikuti isi
                return d;
            }
        };
        Tema.gayaKartu(kartu, 28);

        tambahField(kartu, "Nama Pelanggan", namaCombo, errNama);
        tambahField(kartu, "Nomor HP", hpField, errHp);
        tambahField(kartu, "Layanan", layananCombo, null);
        tambahField(kartu, "Berat", buatInputBerat(), errBerat);
        tambahBlok(kartu, buatRingkasan(), 14);
        tambahField(kartu, "Alamat", alamatScroll, errAlamat);
        tambahField(kartu, "Catatan", catatanScroll, null);
        tambahField(kartu, "Estimasi Selesai (dd-MM-yyyy, boleh dikosongkan)", estimasiField, errEstimasi);
        tambahField(kartu, "Status Awal", statusCombo, null);
        tambahBlok(kartu, buatTombol(), 24);

        return kartu;
    }

    private void tambahField(JPanel kartu, String teksLabel, JComponent input, JLabel error) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.anchor = GridBagConstraints.WEST;

        g.gridy = baris++;
        g.insets = new Insets(baris == 1 ? 0 : 14, 0, 5, 0);
        kartu.add(Tema.label(teksLabel), g);

        g.gridy = baris++;
        g.insets = new Insets(0, 0, 0, 0);
        kartu.add(input, g);

        if (error != null) {
            g.gridy = baris++;
            g.insets = new Insets(3, 0, 0, 0);
            kartu.add(error, g);
        }
    }

    private void tambahBlok(JPanel kartu, JComponent isi, int jarakAtas) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.gridy = baris++;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(jarakAtas, 0, 0, 0);
        kartu.add(isi, g);
    }

    private JPanel buatInputBerat() {
        JLabel kg = new JLabel("Kg", SwingConstants.CENTER);
        kg.setOpaque(true);
        kg.setBackground(new Color(0xE9, 0xEC, 0xEF));
        kg.setForeground(Tema.TEKS);
        kg.setBorder(new CompoundBorder(new MatteBorder(1, 0, 1, 1, Tema.GARIS_INPUT),
                new EmptyBorder(0, 14, 0, 14)));

        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.add(beratField, BorderLayout.CENTER);
        panel.add(kg, BorderLayout.EAST);
        return panel;
    }

    private JPanel buatRingkasan() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(0xF8, 0xF9, 0xFA));
        panel.setBorder(new EmptyBorder(12, 16, 12, 16));

        tambahRingkasan(panel, 0, "Layanan:", ringLayanan, false);
        tambahRingkasan(panel, 1, "Harga/kg:", ringHarga, false);
        tambahRingkasan(panel, 2, "Berat:", ringBerat, false);
        tambahRingkasan(panel, 3, "Total:", ringTotal, true);
        return panel;
    }

    private void tambahRingkasan(JPanel panel, int y, String judul, JLabel nilai, boolean tebal) {
        JLabel label = new JLabel(judul);
        Font font = tebal ? Tema.FONT_TEBAL.deriveFont(17f) : Tema.FONT;
        label.setFont(font);
        label.setForeground(tebal ? Tema.TEKS : Tema.TEKS_PUDAR);
        nilai.setFont(font);
        nilai.setForeground(Tema.TEKS);

        int jarakBawah = tebal ? 0 : 4;
        GridBagConstraints g = new GridBagConstraints();
        g.gridy = y;
        g.anchor = GridBagConstraints.WEST;

        g.gridx = 0;
        g.insets = new Insets(0, 0, jarakBawah, 8);
        panel.add(label, g);

        g.gridx = 1;
        g.weightx = 1;
        g.insets = new Insets(0, 0, jarakBawah, 0);
        panel.add(nilai, g);
    }

    private JPanel buatTombol() {
        JButton simpan = Tema.tombol("Simpan Pesanan", Tema.BIRU, Color.WHITE);
        simpan.setFont(Tema.FONT_TEBAL.deriveFont(15f));
        simpan.setBorder(new EmptyBorder(11, 16, 11, 16));
        simpan.addActionListener(e -> simpanPesanan());

        JButton batal = Tema.tombol("Batal", Tema.ABU, Color.WHITE);
        batal.setFont(Tema.FONT_TEBAL.deriveFont(15f));
        batal.setBorder(new EmptyBorder(11, 24, 11, 24));
        batal.addActionListener(e -> kembali(null));

        getRootPane().setDefaultButton(simpan); // tekan Enter = Simpan Pesanan

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1;
        panel.add(simpan, g);
        g.weightx = 0;
        g.insets = new Insets(0, 8, 0, 0);
        panel.add(batal, g);
        return panel;
    }

    // ------------------------------------------------------------------
    // Input & ringkasan total
    // ------------------------------------------------------------------

    private void siapkanInput() {
        // daftar layanan lengkap dengan harganya
        for (String layanan : DataPesanan.LAYANAN) {
            layananCombo.addItem(layanan + " - " + DataPesanan.formatRupiah(DataPesanan.hargaPerKg(layanan)) + "/kg");
        }

        namaCombo.setEditable(true);
        namaCombo.setSelectedItem("");

        Tema.gayaCombo(namaCombo);
        Tema.gayaCombo(layananCombo);
        Tema.gayaCombo(statusCombo);
        Tema.gayaField(hpField);
        Tema.gayaField(beratField);
        Tema.gayaField(estimasiField);

        // ringkasan ikut berubah saat layanan/berat diubah
        layananCombo.addActionListener(e -> perbaruiRingkasan());
        Tema.saatBerubah(beratField, this::perbaruiRingkasan);

        // tanda salah hilang begitu pengguna mulai mengetik lagi
        JTextComponent editorNama = (JTextComponent) namaCombo.getEditor().getEditorComponent();
        Tema.saatBerubah(editorNama, () -> bersihkan(namaCombo, errNama));
        Tema.saatBerubah(hpField, () -> bersihkan(hpField, errHp));
        Tema.saatBerubah(beratField, () -> bersihkan(beratField, errBerat));
        Tema.saatBerubah(alamatArea, () -> bersihkan(alamatScroll, errAlamat));
        Tema.saatBerubah(estimasiField, () -> bersihkan(estimasiField, errEstimasi));
    }

    private void perbaruiRingkasan() {
        String layanan = layananTerpilih();
        double berat = ambilBerat();

        ringLayanan.setText(layanan);
        ringHarga.setText(DataPesanan.formatRupiah(DataPesanan.hargaPerKg(layanan)));
        ringBerat.setText(berat > 0 ? DataPesanan.formatBerat(berat) + " Kg" : "0 Kg");
        ringTotal.setText(DataPesanan.formatRupiah(berat > 0 ? DataPesanan.hitungTotal(layanan, berat) : 0));
    }

    private String layananTerpilih() {
        return DataPesanan.LAYANAN[Math.max(0, layananCombo.getSelectedIndex())];
    }

    /** Berat dari kolom input; 0 bila kosong atau bukan angka. Koma boleh dipakai sebagai desimal. */
    private double ambilBerat() {
        try {
            double berat = Double.parseDouble(beratField.getText().trim().replace(',', '.'));
            return Double.isFinite(berat) ? berat : 0;
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private String ambilNama() {
        JTextComponent editor = (JTextComponent) namaCombo.getEditor().getEditorComponent();
        return editor.getText().trim();
    }

    // ------------------------------------------------------------------
    // Validasi & simpan
    // ------------------------------------------------------------------

    private void bersihkan(JComponent input, JLabel error) {
        Tema.tandai(input, false);
        if (error.isVisible()) {
            Tema.tampilkan(error, false);
        }
    }

    private boolean periksa(boolean salah, JComponent input, JLabel error) {
        Tema.tandai(input, salah);
        Tema.tampilkan(error, salah);
        return !salah;
    }

    private boolean tanggalValid(String teks) {
        if (teks.isEmpty()) {
            return true; // estimasi boleh kosong
        }
        try {
            LocalDate.parse(teks, FORMAT_TANGGAL);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    private boolean validasi() {
        boolean valid = true;
        valid &= periksa(ambilNama().isEmpty(), namaCombo, errNama);
        valid &= periksa(hpField.getText().trim().isEmpty(), hpField, errHp);
        valid &= periksa(ambilBerat() <= 0, beratField, errBerat);
        valid &= periksa(alamatArea.getText().trim().isEmpty(), alamatScroll, errAlamat);
        valid &= periksa(!tanggalValid(estimasiField.getText().trim()), estimasiField, errEstimasi);
        return valid;
    }

    private void simpanPesanan() {
        if (!validasi()) {
            return;
        }
        DataPesanan.tambah(
                ambilNama(),
                hpField.getText().trim(),
                layananTerpilih(),
                ambilBerat(),
                alamatArea.getText().trim(),
                catatanArea.getText().trim(),
                estimasiField.getText().trim(),
                (String) statusCombo.getSelectedItem());
        kembali("Pesanan baru berhasil dicatat.");
    }

    /** Buka halaman Pesanan (dengan pesan sukses jika ada) dan tutup halaman ini. */
    private void kembali(String pesanNotice) {
        new AdminPesananFrame(pesanNotice).setVisible(true);
        dispose();
    }

    // ------------------------------------------------------------------

    /** Agar file ini bisa dijalankan sendiri (mis. "Run File" di NetBeans). */
    public static void main(String[] args) {
        Tema.pasangTampilan();
        SwingUtilities.invokeLater(() -> new AdminPesananBaruFrame().setVisible(true));
    }
}
