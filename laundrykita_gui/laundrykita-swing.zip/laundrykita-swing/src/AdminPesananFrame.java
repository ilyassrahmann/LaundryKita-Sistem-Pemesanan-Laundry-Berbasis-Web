import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Halaman "Kelola Pesanan" (admin-pesanan.html): cari, filter status,
 * tabel pesanan, dan dialog detail untuk mengubah status.
 */
public class AdminPesananFrame extends JFrame {

    private static final int KOLOM_STATUS = 5;
    private static final int KOLOM_AKSI = 6;
    private static final String SEMUA_STATUS = "Semua Status";

    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Pelanggan", "Layanan", "Berat", "Total", "Status", "Aksi"}, 0) {
        @Override
        public boolean isCellEditable(int baris, int kolom) {
            return false;
        }
    };
    private final JTable tabel = new JTable(model);
    private final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
    private final JTextField cariField = new JTextField();
    private final JComboBox<String> filterStatus = new JComboBox<>();
    private final JLabel notice = new JLabel();
    private final JLabel kosong = new JLabel("Tidak ada pesanan yang cocok.", SwingConstants.CENTER);

    public AdminPesananFrame() {
        this(null);
    }

    /** @param pesanNotice pesan sukses di bagian atas halaman (boleh null) */
    public AdminPesananFrame(String pesanNotice) {
        super("LaundryKita - Kelola Pesanan");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 680);
        setMinimumSize(new Dimension(820, 520));
        setLocationRelativeTo(null);
        getContentPane().setBackground(Tema.LATAR);
        setLayout(new BorderLayout());

        siapkanFilter();
        siapkanTabel();

        add(new NavbarAdmin(this, NavbarAdmin.PESANAN), BorderLayout.NORTH);
        add(buatKonten(), BorderLayout.CENTER);
        add(Tema.footer(), BorderLayout.SOUTH);

        muatData();
        if (pesanNotice != null) {
            tampilkanNotice(pesanNotice);
        }
    }

    // ------------------------------------------------------------------
    // Susunan halaman
    // ------------------------------------------------------------------

    private JPanel buatKonten() {
        JPanel isi = new JPanel(new GridBagLayout());
        isi.setBackground(Tema.LATAR);
        isi.setBorder(new EmptyBorder(24, 40, 24, 40));

        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(0, 0, 16, 0);

        g.gridy = 0;
        isi.add(buatHeader(), g);

        g.gridy = 1;
        isi.add(buatNotice(), g);

        g.gridy = 2;
        isi.add(buatKartuFilter(), g);

        g.gridy = 3;
        g.weighty = 1;
        g.fill = GridBagConstraints.BOTH;
        g.insets = new Insets(0, 0, 0, 0);
        isi.add(buatKartuTabel(), g);

        return isi;
    }

    private JPanel buatHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel judul = new JLabel("Kelola Pesanan");
        judul.setFont(Tema.FONT_JUDUL);
        judul.setForeground(Tema.TEKS);
        judul.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel sub = new JLabel("Lihat dan kelola seluruh pesanan pelanggan.");
        sub.setForeground(Tema.TEKS_PUDAR);
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel teks = new JPanel();
        teks.setLayout(new BoxLayout(teks, BoxLayout.Y_AXIS));
        teks.setOpaque(false);
        teks.add(judul);
        teks.add(Box.createVerticalStrut(4));
        teks.add(sub);

        JButton baru = Tema.tombol("+ Pesanan Baru", Tema.BIRU, Color.WHITE);
        baru.addActionListener(e -> {
            new AdminPesananBaruFrame().setVisible(true);
            dispose();
        });
        JPanel kanan = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        kanan.setOpaque(false);
        kanan.add(baru);

        header.add(teks, BorderLayout.WEST);
        header.add(kanan, BorderLayout.EAST);
        return header;
    }

    private JLabel buatNotice() {
        notice.setOpaque(true);
        notice.setBackground(new Color(0xD1, 0xE7, 0xDD));
        notice.setForeground(new Color(0x0F, 0x51, 0x32));
        notice.setBorder(new CompoundBorder(new LineBorder(new Color(0xBA, 0xDB, 0xCC)),
                new EmptyBorder(12, 16, 12, 16)));
        notice.setVisible(false);
        return notice;
    }

    private JPanel buatKartuFilter() {
        JPanel kartu = Tema.kartu(new GridBagLayout(), 16);

        Tema.gayaField(cariField);
        Tema.gayaCombo(filterStatus);

        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.anchor = GridBagConstraints.WEST;

        g.gridx = 0; g.gridy = 0; g.weightx = 0.7; g.insets = new Insets(0, 0, 6, 12);
        kartu.add(Tema.label("Cari Pesanan"), g);
        g.gridx = 1; g.weightx = 0.3; g.insets = new Insets(0, 0, 6, 0);
        kartu.add(Tema.label("Filter Status"), g);

        g.gridx = 0; g.gridy = 1; g.weightx = 0.7; g.insets = new Insets(0, 0, 0, 12);
        kartu.add(cariField, g);
        g.gridx = 1; g.weightx = 0.3; g.insets = new Insets(0, 0, 0, 0);
        kartu.add(filterStatus, g);

        return kartu;
    }

    private JPanel buatKartuTabel() {
        JPanel kartu = Tema.kartu(new BorderLayout(), 0);

        JScrollPane scroll = new JScrollPane(tabel);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(Color.WHITE);

        kosong.setForeground(Tema.TEKS_PUDAR);
        kosong.setBorder(new EmptyBorder(20, 0, 20, 0));
        kosong.setVisible(false);

        kartu.add(scroll, BorderLayout.CENTER);
        kartu.add(kosong, BorderLayout.SOUTH);
        return kartu;
    }

    // ------------------------------------------------------------------
    // Filter (cari + status)
    // ------------------------------------------------------------------

    private void siapkanFilter() {
        filterStatus.addItem(SEMUA_STATUS);
        for (String status : DataPesanan.DAFTAR_STATUS) {
            filterStatus.addItem(status);
        }
        Tema.saatBerubah(cariField, this::terapkanFilter);
        filterStatus.addActionListener(e -> terapkanFilter());
    }

    private void terapkanFilter() {
        List<RowFilter<Object, Object>> syarat = new ArrayList<>();

        String kata = cariField.getText().trim();
        if (!kata.isEmpty()) {
            // cocokkan ke kolom ID (0) atau Pelanggan (1), tanpa membedakan huruf besar/kecil
            syarat.add(RowFilter.regexFilter("(?i)" + Pattern.quote(kata), 0, 1));
        }

        String status = (String) filterStatus.getSelectedItem();
        if (status != null && !status.equals(SEMUA_STATUS)) {
            syarat.add(RowFilter.regexFilter("^" + Pattern.quote(status) + "$", KOLOM_STATUS));
        }

        RowFilter<Object, Object> filter = syarat.isEmpty() ? null : RowFilter.andFilter(syarat);
        sorter.setRowFilter(filter);
        perbaruiPesanKosong();
    }

    private void perbaruiPesanKosong() {
        Tema.tampilkan(kosong, tabel.getRowCount() == 0);
    }

    // ------------------------------------------------------------------
    // Tabel
    // ------------------------------------------------------------------

    private void siapkanTabel() {
        tabel.setRowHeight(42);
        tabel.setShowVerticalLines(false);
        tabel.setGridColor(Tema.GARIS);
        tabel.setSelectionBackground(new Color(0xE8, 0xF0, 0xFB));
        tabel.setSelectionForeground(Tema.TEKS);
        tabel.setForeground(Tema.TEKS);
        tabel.setFillsViewportHeight(true);
        tabel.setRowSorter(sorter);
        for (int i = 0; i < model.getColumnCount(); i++) {
            sorter.setSortable(i, false);
        }

        // header tabel
        tabel.getTableHeader().setReorderingAllowed(false);
        tabel.getTableHeader().setPreferredSize(new Dimension(100, 42));
        tabel.getTableHeader().setDefaultRenderer((t, nilai, dipilih, fokus, baris, kolom) -> {
            JLabel l = new JLabel(String.valueOf(nilai));
            l.setOpaque(true);
            l.setFont(Tema.FONT_TEBAL);
            l.setForeground(Tema.TEKS);
            l.setBackground(new Color(0xF8, 0xF9, 0xFA));
            l.setBorder(new CompoundBorder(new MatteBorder(0, 0, 2, 0, Tema.GARIS),
                    new EmptyBorder(0, 12, 0, 12)));
            return l;
        });

        // isi sel biasa: beri jarak kiri-kanan
        tabel.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object nilai, boolean dipilih,
                                                           boolean fokus, int baris, int kolom) {
                super.getTableCellRendererComponent(t, nilai, dipilih, false, baris, kolom);
                setBorder(new EmptyBorder(0, 12, 0, 12));
                return this;
            }
        });

        int[] lebar = {80, 150, 150, 80, 110, 120, 100};
        for (int i = 0; i < lebar.length; i++) {
            tabel.getColumnModel().getColumn(i).setPreferredWidth(lebar[i]);
        }
        tabel.getColumnModel().getColumn(KOLOM_STATUS).setCellRenderer(new StatusRenderer());
        tabel.getColumnModel().getColumn(KOLOM_AKSI).setCellRenderer(new AksiRenderer());

        // klik kolom Aksi (atau klik dua kali di baris mana pun) membuka detail
        tabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int baris = tabel.rowAtPoint(e.getPoint());
                int kolom = tabel.columnAtPoint(e.getPoint());
                if (baris < 0 || kolom < 0) {
                    return;
                }
                boolean diAksi = tabel.convertColumnIndexToModel(kolom) == KOLOM_AKSI;
                if (diAksi || e.getClickCount() == 2) {
                    bukaDetail(tabel.convertRowIndexToModel(baris));
                }
            }
        });
        tabel.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int kolom = tabel.columnAtPoint(e.getPoint());
                boolean diAksi = kolom >= 0 && tabel.rowAtPoint(e.getPoint()) >= 0
                        && tabel.convertColumnIndexToModel(kolom) == KOLOM_AKSI;
                tabel.setCursor(Cursor.getPredefinedCursor(
                        diAksi ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
            }
        });
    }

    /** Isi ulang tabel dari DataPesanan (urutan baris sama dengan urutan data). */
    private void muatData() {
        model.setRowCount(0);
        for (Pesanan p : DataPesanan.semua()) {
            model.addRow(new Object[]{p.getId(), p.getNama(), p.getLayanan(),
                    p.getBeratTeks(), p.getTotalTeks(), p.getStatus(), "Detail"});
        }
        perbaruiPesanKosong();
    }

    private void tampilkanNotice(String teks) {
        notice.setText(teks);
        Tema.tampilkan(notice, true);
    }

    // ------------------------------------------------------------------
    // Dialog detail pesanan
    // ------------------------------------------------------------------

    /** @param indeks urutan pesanan di DataPesanan (bukan urutan baris yang tampil) */
    void bukaDetail(int indeks) {
        Pesanan p = DataPesanan.semua().get(indeks);

        JDialog dialog = new JDialog(this, "Detail Pesanan " + p.getId(), true);
        dialog.getContentPane().setBackground(Color.WHITE);
        dialog.setLayout(new BorderLayout());

        JPanel isi = new JPanel(new GridBagLayout());
        isi.setOpaque(false);
        isi.setBorder(new EmptyBorder(20, 24, 8, 24));

        JLabel judul = new JLabel("Detail Pesanan " + p.getId());
        judul.setFont(Tema.FONT_TEBAL.deriveFont(18f));
        judul.setForeground(Tema.TEKS);
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0; g.gridy = 0; g.gridwidth = 2;
        g.anchor = GridBagConstraints.WEST;
        g.insets = new Insets(0, 0, 16, 0);
        isi.add(judul, g);

        tambahBaris(isi, 1, "Nama Pelanggan:", p.getNama());
        tambahBaris(isi, 2, "Layanan:", p.getLayanan());
        tambahBaris(isi, 3, "Berat:", p.getBeratTeks());
        tambahBaris(isi, 4, "Total:", p.getTotalTeks());
        tambahBaris(isi, 5, "Alamat:", p.getAlamat().isEmpty() ? "-" : p.getAlamat());

        JComboBox<String> ubahStatus = new JComboBox<>(DataPesanan.DAFTAR_STATUS);
        ubahStatus.setSelectedItem(p.getStatus());
        Tema.gayaCombo(ubahStatus);

        g = new GridBagConstraints();
        g.gridx = 0; g.gridy = 6;
        g.anchor = GridBagConstraints.WEST;
        g.insets = new Insets(8, 0, 0, 12);
        isi.add(Tema.label("Ubah Status"), g);
        g.gridx = 1; g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(8, 0, 0, 0);
        isi.add(ubahStatus, g);

        JButton tutup = Tema.tombol("Tutup", Tema.ABU, Color.WHITE);
        JButton simpan = Tema.tombol("Simpan Status", Tema.BIRU, Color.WHITE);
        tutup.addActionListener(e -> dialog.dispose());
        simpan.addActionListener(e -> {
            String statusBaru = (String) ubahStatus.getSelectedItem();
            p.setStatus(statusBaru);
            muatData();
            tampilkanNotice("Status " + p.getId() + " diubah menjadi " + statusBaru + ".");
            dialog.dispose();
        });

        JPanel tombol = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 12));
        tombol.setOpaque(false);
        tombol.setBorder(new EmptyBorder(0, 16, 4, 16));
        tombol.add(tutup);
        tombol.add(simpan);

        dialog.add(isi, BorderLayout.CENTER);
        dialog.add(tombol, BorderLayout.SOUTH);
        dialog.pack();
        dialog.setMinimumSize(new Dimension(440, dialog.getHeight()));
        dialog.setResizable(false);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void tambahBaris(JPanel panel, int y, String judul, String nilai) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridy = y;
        g.anchor = GridBagConstraints.NORTHWEST;

        g.gridx = 0;
        g.insets = new Insets(0, 0, 8, 12);
        panel.add(Tema.label(judul), g);

        JLabel isi = new JLabel("<html><body style='width:240px'>" + esc(nilai) + "</body></html>");
        isi.setForeground(Tema.TEKS);
        g.gridx = 1;
        g.weightx = 1;
        g.insets = new Insets(0, 0, 8, 0);
        panel.add(isi, g);
    }

    /** Hindari teks pelanggan dibaca sebagai tag HTML di dalam JLabel. */
    private static String esc(String teks) {
        return teks.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    // ------------------------------------------------------------------
    // Renderer kolom Status (badge) dan Aksi (tombol Detail)
    // ------------------------------------------------------------------

    private static class StatusBadge extends JLabel {
        private Color warna = Tema.ABU;

        StatusBadge() {
            setFont(Tema.FONT_TEBAL.deriveFont(12f));
            setBorder(new EmptyBorder(3, 10, 3, 10));
            setOpaque(false);
        }

        void setStatus(String status) {
            setText(status);
            warna = Tema.warnaStatus(status);
            setForeground(Tema.warnaTeksStatus(status));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(warna);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private static class StatusRenderer implements TableCellRenderer {
        private final JPanel panel = new JPanel(new GridBagLayout());
        private final StatusBadge badge = new StatusBadge();

        StatusRenderer() {
            GridBagConstraints g = new GridBagConstraints();
            g.anchor = GridBagConstraints.WEST;
            g.weightx = 1;
            g.insets = new Insets(0, 12, 0, 0);
            panel.add(badge, g);
        }

        @Override
        public Component getTableCellRendererComponent(JTable t, Object nilai, boolean dipilih,
                                                       boolean fokus, int baris, int kolom) {
            badge.setStatus(String.valueOf(nilai));
            panel.setBackground(dipilih ? t.getSelectionBackground() : t.getBackground());
            return panel;
        }
    }

    private static class AksiRenderer implements TableCellRenderer {
        private final JPanel panel = new JPanel(new GridBagLayout());
        private final JButton tombol = Tema.tombol("Detail", Tema.BIRU, Color.WHITE);

        AksiRenderer() {
            tombol.setFont(Tema.FONT_KECIL);
            tombol.setBorder(new EmptyBorder(5, 14, 5, 14));
            GridBagConstraints g = new GridBagConstraints();
            g.anchor = GridBagConstraints.WEST;
            g.weightx = 1;
            g.insets = new Insets(0, 12, 0, 0);
            panel.add(tombol, g);
        }

        @Override
        public Component getTableCellRendererComponent(JTable t, Object nilai, boolean dipilih,
                                                       boolean fokus, int baris, int kolom) {
            panel.setBackground(dipilih ? t.getSelectionBackground() : t.getBackground());
            return panel;
        }
    }

    // ------------------------------------------------------------------

    /** Agar file ini bisa dijalankan sendiri (mis. "Run File" di NetBeans). */
    public static void main(String[] args) {
        Main.main(args);
    }
}
