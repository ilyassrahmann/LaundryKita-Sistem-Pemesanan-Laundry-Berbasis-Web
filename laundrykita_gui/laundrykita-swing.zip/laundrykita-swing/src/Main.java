import javax.swing.SwingUtilities;

/**
 * Titik masuk aplikasi: membuka halaman admin-pesanan.
 */
public class Main {

    public static void main(String[] args) {
        Tema.pasangTampilan();
        SwingUtilities.invokeLater(() -> new AdminPesananFrame().setVisible(true));
    }
}
