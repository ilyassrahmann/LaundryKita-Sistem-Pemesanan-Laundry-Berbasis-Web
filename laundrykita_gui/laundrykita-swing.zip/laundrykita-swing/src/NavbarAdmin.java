import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * Navbar admin (LaundryKita [Admin] | Dashboard, Pesanan, Pesanan Baru, Pelanggan, Keluar).
 * Hanya halaman Pesanan dan Pesanan Baru yang sudah dibuat.
 */
public class NavbarAdmin extends JPanel {

    public static final String DASHBOARD = "Dashboard";
    public static final String PESANAN = "Pesanan";
    public static final String PESANAN_BARU = "Pesanan Baru";
    public static final String PELANGGAN = "Pelanggan";

    private final JFrame frame;
    private final String aktif;

    public NavbarAdmin(JFrame frame, String aktif) {
        this.frame = frame;
        this.aktif = aktif;

        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(new CompoundBorder(new MatteBorder(0, 0, 2, 0, Tema.KUNING),
                new EmptyBorder(10, 24, 10, 24)));

        add(buatMerek(), BorderLayout.WEST);
        add(buatMenu(), BorderLayout.EAST);
    }

    private JPanel buatMerek() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        panel.setOpaque(false);

        JLabel merek = new JLabel("LaundryKita");
        merek.setFont(Tema.FONT_TEBAL.deriveFont(19f));
        merek.setForeground(Tema.BIRU);

        JLabel badge = new JLabel("Admin");
        badge.setFont(Tema.FONT_TEBAL.deriveFont(11f));
        badge.setForeground(new Color(0x22, 0x22, 0x22));
        badge.setBackground(Tema.KUNING);
        badge.setOpaque(true);
        badge.setBorder(new EmptyBorder(3, 8, 3, 8));

        panel.add(merek);
        panel.add(badge);
        return panel;
    }

    private JPanel buatMenu() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        panel.setOpaque(false);

        panel.add(linkMenu(DASHBOARD));
        panel.add(linkMenu(PESANAN));
        panel.add(linkMenu(PESANAN_BARU));
        panel.add(linkMenu(PELANGGAN));
        panel.add(tombolKeluar());
        return panel;
    }

    private JButton linkMenu(String nama) {
        boolean sedangAktif = nama.equals(aktif);

        JButton b = new JButton(nama);
        b.setFont(sedangAktif ? Tema.FONT_TEBAL : Tema.FONT);
        b.setForeground(sedangAktif ? Tema.BIRU : new Color(0x44, 0x44, 0x44));
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(e -> buka(nama));
        return b;
    }

    private JButton tombolKeluar() {
        JButton b = new JButton("Keluar");
        b.setFont(Tema.FONT);
        b.setForeground(Tema.MERAH);
        b.setBackground(Color.WHITE);
        b.setOpaque(true);
        b.setFocusPainted(false);
        b.setBorder(new CompoundBorder(new LineBorder(Tema.MERAH), new EmptyBorder(4, 14, 4, 14)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(e -> {
            int pilihan = JOptionPane.showConfirmDialog(frame, "Yakin ingin keluar?",
                    "Keluar", JOptionPane.YES_NO_OPTION);
            if (pilihan == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        });
        return b;
    }

    private void buka(String tujuan) {
        if (tujuan.equals(aktif)) {
            return;
        }
        switch (tujuan) {
            case PESANAN:
                new AdminPesananFrame().setVisible(true);
                frame.dispose();
                break;
            case PESANAN_BARU:
                new AdminPesananBaruFrame().setVisible(true);
                frame.dispose();
                break;
            default:
                JOptionPane.showMessageDialog(frame, "Halaman " + tujuan + " belum dibuat.",
                        "LaundryKita", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
