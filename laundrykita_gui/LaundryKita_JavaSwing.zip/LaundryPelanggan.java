import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LaundryPelanggan extends JFrame {

    public LaundryPelanggan() {
        setTitle("LaundryKita - Pelanggan");
        setSize(960, 850);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main Panel (Web Background)
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(248, 249, 250));

        // 1. Header Navbar
        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);

        // 2. Content Body (Scrollable)
        JPanel contentPanel = createContentPanel();
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // 3. Footer
        mainPanel.add(createFooterPanel(), BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel createHeaderPanel() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(Color.WHITE);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(new EmptyBorder(15, 40, 15, 40));

        // Logo
        JLabel logoLabel = new JLabel("LaundryKita");
        logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        logoLabel.setForeground(new Color(13, 110, 253));
        header.add(logoLabel, BorderLayout.WEST);

        // Nav Menu
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 0));
        navPanel.setBackground(Color.WHITE);

        JLabel lblBeranda = new JLabel("Beranda");
        lblBeranda.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblBeranda.setForeground(new Color(13, 110, 253));

        JLabel lblPesanan = new JLabel("Pesanan Saya");
        lblPesanan.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblPesanan.setForeground(new Color(108, 117, 125));

        JLabel lblProfil = new JLabel("Profil");
        lblProfil.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblProfil.setForeground(new Color(108, 117, 125));

        JButton btnKeluar = new JButton("Keluar");
        btnKeluar.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnKeluar.setForeground(new Color(220, 53, 69));
        btnKeluar.setBackground(Color.WHITE);
        btnKeluar.setBorder(BorderFactory.createLineBorder(new Color(220, 53, 69)));
        btnKeluar.setFocusPainted(false);
        btnKeluar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnKeluar.setPreferredSize(new Dimension(75, 28));

        navPanel.add(lblBeranda);
        navPanel.add(lblPesanan);
        navPanel.add(lblProfil);
        navPanel.add(btnKeluar);

        header.add(navPanel, BorderLayout.EAST);
        wrapper.add(header, BorderLayout.CENTER);

        // Yellow Bottom Line
        JPanel yellowLine = new JPanel();
        yellowLine.setBackground(new Color(255, 193, 7));
        yellowLine.setPreferredSize(new Dimension(0, 3));
        wrapper.add(yellowLine, BorderLayout.SOUTH);

        return wrapper;
    }

    private JPanel createContentPanel() {
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(new Color(248, 249, 250));
        content.setBorder(new EmptyBorder(35, 60, 35, 60));

        // --- SECTION 1: HERO / WELCOME ---
        JPanel heroPanel = new JPanel(new BorderLayout(20, 0));
        heroPanel.setBackground(new Color(248, 249, 250));
        heroPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 140));

        JPanel heroText = new JPanel();
        heroText.setLayout(new BoxLayout(heroText, BoxLayout.Y_AXIS));
        heroText.setBackground(new Color(248, 249, 250));

        JLabel titleWelcome = new JLabel("Halo, Averroes! 👋");
        titleWelcome.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleWelcome.setForeground(new Color(33, 37, 41));

        JLabel subWelcome = new JLabel("Pantau status laundry kamu di sini.");
        subWelcome.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subWelcome.setForeground(new Color(108, 117, 125));
        subWelcome.setBorder(new EmptyBorder(6, 0, 15, 0));

        JButton btnLacak = new JButton("Lacak Pesanan");
        stylePrimaryButton(btnLacak);

        heroText.add(titleWelcome);
        heroText.add(subWelcome);
        heroText.add(btnLacak);

        // Banner Store Placeholder
        JPanel bannerCard = new JPanel(new BorderLayout());
        bannerCard.setBackground(Color.WHITE);
        bannerCard.setPreferredSize(new Dimension(300, 130));
        bannerCard.setBorder(BorderFactory.createLineBorder(new Color(222, 226, 230)));
        JLabel bannerText = new JLabel("<html><center><b>LaundryKita Store</b><br><span style='color:gray; font-size:11px;'>Laundry jadi lebih mudah!</span></center></html>", JLabel.CENTER);
        bannerCard.add(bannerText, BorderLayout.CENTER);

        heroPanel.add(heroText, BorderLayout.WEST);
        heroPanel.add(bannerCard, BorderLayout.EAST);
        content.add(heroPanel);

        content.add(Box.createRigidArea(new Dimension(0, 35)));

        // --- SECTION 2: PESANAN AKTIF ---
        JLabel lblSectionPesanan = new JLabel("Pesanan Aktif");
        lblSectionPesanan.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblSectionPesanan.setForeground(new Color(33, 37, 41));
        
        JPanel pTitle1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        pTitle1.setBackground(new Color(248, 249, 250));
        pTitle1.add(lblSectionPesanan);
        content.add(pTitle1);
        content.add(Box.createRigidArea(new Dimension(0, 12)));

        JPanel orderCard = new JPanel();
        orderCard.setLayout(new BoxLayout(orderCard, BoxLayout.Y_AXIS));
        orderCard.setBackground(Color.WHITE);
        orderCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(222, 226, 230)),
                new EmptyBorder(20, 20, 20, 20)
        ));
        orderCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 210));

        // Top Order Info
        JPanel orderTop = new JPanel(new BorderLayout());
        orderTop.setBackground(Color.WHITE);
        JLabel orderId = new JLabel("Pesanan #LK023");
        orderId.setFont(new Font("Segoe UI", Font.BOLD, 15));
        
        JLabel badgeDiproses = new JLabel(" Diproses ");
        badgeDiproses.setFont(new Font("Segoe UI", Font.BOLD, 11));
        badgeDiproses.setForeground(Color.WHITE);
        badgeDiproses.setOpaque(true);
        badgeDiproses.setBackground(new Color(13, 110, 253));
        
        orderTop.add(orderId, BorderLayout.WEST);
        orderTop.add(badgeDiproses, BorderLayout.EAST);
        orderCard.add(orderTop);

        JLabel orderDate = new JLabel("28-10-2026");
        orderDate.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        orderDate.setForeground(new Color(108, 117, 125));
        orderCard.add(orderDate);

        orderCard.add(Box.createRigidArea(new Dimension(0, 10)));
        JSeparator sep = new JSeparator();
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        sep.setForeground(new Color(222, 226, 230));
        orderCard.add(sep);
        orderCard.add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel orderInfo = new JLabel("Layanan: Cuci Kering (4 Kg), Setrika Saja (1,5 Kg)");
        orderInfo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        orderCard.add(orderInfo);

        orderCard.add(Box.createRigidArea(new Dimension(0, 4)));
        JLabel orderTotal = new JLabel("Total berat: 5,5 Kg   Total: Rp37.000 (Lunas)");
        orderTotal.setFont(new Font("Segoe UI", Font.BOLD, 13));
        orderTotal.setForeground(new Color(40, 167, 69));
        orderCard.add(orderTotal);

        orderCard.add(Box.createRigidArea(new Dimension(0, 12)));
        JButton btnDetail = new JButton("Lihat Detail");
        stylePrimaryButton(btnDetail);
        orderCard.add(btnDetail);

        content.add(orderCard);

        content.add(Box.createRigidArea(new Dimension(0, 40)));

        // --- SECTION 3: DAFTAR LAYANAN & HARGA ---
        JPanel layananHeader = new JPanel();
        layananHeader.setLayout(new BoxLayout(layananHeader, BoxLayout.Y_AXIS));
        layananHeader.setBackground(new Color(248, 249, 250));

        JLabel lblLayanan = new JLabel("Daftar Layanan & Harga");
        lblLayanan.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblLayanan.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblSubLayanan = new JLabel("Harga per kilogram");
        lblSubLayanan.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSubLayanan.setForeground(new Color(108, 117, 125));
        lblSubLayanan.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblSubLayanan.setBorder(new EmptyBorder(4, 0, 15, 0));

        layananHeader.add(lblLayanan);
        layananHeader.add(lblSubLayanan);
        content.add(layananHeader);

        JPanel gridLayanan = new JPanel(new GridLayout(1, 3, 15, 0));
        gridLayanan.setBackground(new Color(248, 249, 250));
        gridLayanan.setMaximumSize(new Dimension(Integer.MAX_VALUE, 180));

        gridLayanan.add(createServiceCard("Cuci Kering", "Cucian dicuci bersih lalu dikeringkan, siap pakai.", "Rp7.000 / kg"));
        gridLayanan.add(createServiceCard("Cuci Setrika", "Dicuci, dikeringkan, dan disetrika rapi.", "Rp10.000 / kg"));
        gridLayanan.add(createServiceCard("Setrika Saja", "Khusus pakaian bersih yang hanya perlu disetrika.", "Rp6.000 / kg"));

        content.add(gridLayanan);

        content.add(Box.createRigidArea(new Dimension(0, 40)));

        // --- SECTION 4: CARA MEMESAN ---
        JLabel lblCaraMemesan = new JLabel("Cara Memesan");
        lblCaraMemesan.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblCaraMemesan.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JPanel pCaraHeader = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pCaraHeader.setBackground(new Color(248, 249, 250));
        pCaraHeader.add(lblCaraMemesan);
        content.add(pCaraHeader);
        content.add(Box.createRigidArea(new Dimension(0, 15)));

        JPanel gridCara = new JPanel(new GridLayout(1, 3, 15, 0));
        gridCara.setBackground(new Color(248, 249, 250));
        gridCara.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));

        gridCara.add(createSimpleCard("Antar cucianmu", "Bawa laundry ke outlet atau hubungi kami via WhatsApp."));
        gridCara.add(createSimpleCard("Petugas mencatat", "Petugas menimbang dan mencatat pesananmu."));
        gridCara.add(createSimpleCard("Pantau di sini", "Lihat status laundry kapan saja di halaman Pesanan Saya."));

        content.add(gridCara);

        content.add(Box.createRigidArea(new Dimension(0, 20)));

        // WhatsApp Button
        JPanel pWa = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pWa.setBackground(new Color(248, 249, 250));
        JButton btnWa = new JButton("Hubungi via WhatsApp");
        stylePrimaryButton(btnWa);
        pWa.add(btnWa);
        content.add(pWa);

        return content;
    }

    private JPanel createServiceCard(String title, String desc, String price) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(222, 226, 230)),
                new EmptyBorder(15, 15, 15, 15)
        ));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 15));
        card.add(titleLbl);

        card.add(Box.createRigidArea(new Dimension(0, 8)));
        JLabel descLbl = new JLabel("<html><body style='width: 160px'>" + desc + "</body></html>");
        descLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        descLbl.setForeground(new Color(108, 117, 125));
        card.add(descLbl);

        card.add(Box.createRigidArea(new Dimension(0, 15)));
        JLabel priceLbl = new JLabel(price);
        priceLbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        priceLbl.setForeground(new Color(13, 110, 253));
        card.add(priceLbl);

        return card;
    }

    private JPanel createSimpleCard(String title, String desc) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(222, 226, 230)),
                new EmptyBorder(15, 15, 15, 15)
        ));

        JLabel titleLbl = new JLabel(title, JLabel.CENTER);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(titleLbl);

        card.add(Box.createRigidArea(new Dimension(0, 8)));
        JLabel descLbl = new JLabel("<html><center style='width: 160px'>" + desc + "</center></html>", JLabel.CENTER);
        descLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        descLbl.setForeground(new Color(108, 117, 125));
        descLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(descLbl);

        return card;
    }

    private JPanel createFooterPanel() {
        JPanel footer = new JPanel();
        footer.setLayout(new BoxLayout(footer, BoxLayout.Y_AXIS));
        footer.setBackground(Color.WHITE);
        footer.setBorder(new EmptyBorder(15, 0, 15, 0));
        
        JLabel lblFooter1 = new JLabel("© 2026 LaundryKita — Sistem Pemesanan Laundry", JLabel.CENTER);
        lblFooter1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFooter1.setForeground(new Color(108, 117, 125));
        lblFooter1.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblFooter2 = new JLabel("WhatsApp 0812-3456-7890 - Buka setiap hari 08.00-20.00", JLabel.CENTER);
        lblFooter2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblFooter2.setForeground(new Color(108, 117, 125));
        lblFooter2.setAlignmentX(Component.CENTER_ALIGNMENT);

        footer.add(lblFooter1);
        footer.add(Box.createRigidArea(new Dimension(0, 4)));
        footer.add(lblFooter2);

        return footer;
    }

    private void stylePrimaryButton(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(13, 110, 253));
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(8, 16, 8, 16));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new LaundryPelanggan().setVisible(true));
    }
}