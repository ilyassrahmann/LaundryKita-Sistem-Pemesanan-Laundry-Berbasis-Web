import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;

public class LaundryAdmin extends JFrame {

    public LaundryAdmin() {
        setTitle("LaundryKita - Admin Dashboard");
        setSize(1060, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(248, 249, 250));

        // Header Admin
        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);

        // Content Area (Tabel Data Pelanggan)
        mainPanel.add(createContentPanel(), BorderLayout.CENTER);

        // Footer
        mainPanel.add(createFooterPanel(), BorderLayout.SOUTH);

        add(mainPanel);
    }

    private JPanel createHeaderPanel() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(Color.WHITE);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(new EmptyBorder(15, 40, 15, 40));

        // Logo + Badge Admin Kuning
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        logoPanel.setBackground(Color.WHITE);
        
        JLabel logoLabel = new JLabel("LaundryKita");
        logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        logoLabel.setForeground(new Color(13, 110, 253));

        JLabel adminBadge = new JLabel(" Admin ");
        adminBadge.setFont(new Font("Segoe UI", Font.BOLD, 11));
        adminBadge.setForeground(new Color(33, 37, 41));
        adminBadge.setOpaque(true);
        adminBadge.setBackground(new Color(255, 193, 7));

        logoPanel.add(logoLabel);
        logoPanel.add(adminBadge);
        header.add(logoPanel, BorderLayout.WEST);

        // Nav Menu Admin
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 0));
        navPanel.setBackground(Color.WHITE);
        
        JLabel lblDashboard = new JLabel("Dashboard");
        lblDashboard.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblDashboard.setForeground(new Color(108, 117, 125));

        JLabel lblPesanan = new JLabel("Pesanan");
        lblPesanan.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblPesanan.setForeground(new Color(108, 117, 125));

        JLabel lblPesananBaru = new JLabel("Pesanan Baru");
        lblPesananBaru.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblPesananBaru.setForeground(new Color(108, 117, 125));

        JLabel lblPelanggan = new JLabel("Pelanggan");
        lblPelanggan.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblPelanggan.setForeground(new Color(13, 110, 253));

        JButton btnKeluar = new JButton("Keluar");
        btnKeluar.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnKeluar.setForeground(new Color(220, 53, 69));
        btnKeluar.setBackground(Color.WHITE);
        btnKeluar.setBorder(BorderFactory.createLineBorder(new Color(220, 53, 69)));
        btnKeluar.setFocusPainted(false);
        btnKeluar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnKeluar.setPreferredSize(new Dimension(75, 28));

        navPanel.add(lblDashboard);
        navPanel.add(lblPesanan);
        navPanel.add(lblPesananBaru);
        navPanel.add(lblPelanggan);
        navPanel.add(btnKeluar);

        header.add(navPanel, BorderLayout.EAST);
        wrapper.add(header, BorderLayout.CENTER);

        JPanel yellowLine = new JPanel();
        yellowLine.setBackground(new Color(255, 193, 7));
        yellowLine.setPreferredSize(new Dimension(0, 3));
        wrapper.add(yellowLine, BorderLayout.SOUTH);

        return wrapper;
    }

    private JPanel createContentPanel() {
        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(new Color(248, 249, 250));
        content.setBorder(new EmptyBorder(30, 40, 30, 40));

        // Top Content Section (Judul & Tombol Tambah)
        JPanel topContent = new JPanel(new BorderLayout());
        topContent.setBackground(new Color(248, 249, 250));

        JLabel title = new JLabel("Data Pelanggan");
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setForeground(new Color(33, 37, 41));
        topContent.add(title, BorderLayout.WEST);

        JButton btnTambah = new JButton("+ Tambah Pelanggan");
        btnTambah.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnTambah.setForeground(Color.WHITE);
        btnTambah.setBackground(new Color(13, 110, 253));
        btnTambah.setFocusPainted(false);
        btnTambah.setBorder(new EmptyBorder(8, 16, 8, 16));
        btnTambah.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        JPanel btnWrapper = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        btnWrapper.setBackground(new Color(248, 249, 250));
        btnWrapper.add(btnTambah);
        topContent.add(btnWrapper, BorderLayout.EAST);

        content.add(topContent, BorderLayout.NORTH);

        // Spacing
        JPanel spacePanel = new JPanel();
        spacePanel.setBackground(new Color(248, 249, 250));
        spacePanel.setPreferredSize(new Dimension(0, 20));

        // JTable Data Pelanggan
        String[] columns = {"Nama", "Email", "No. HP", "Alamat", "Pesanan", "Aksi"};
        Object[][] data = {
            {"Averroes", "averroes@email.com", "083178901234", "Jl. Riau No. 150, Pekanbaru", "2 pesanan", ""},
            {"Dihar", "dihar@email.com", "081365778899", "Jl. Arifin Achmad No. 21, Pekanbaru", "5 pesanan", ""},
            {"Dinda", "dinda@email.com", "084567890123", "Jl. Ahmad Yani No. 8, Pekanbaru", "3 pesanan", ""},
            {"fakhry", "fakhry@email.com", "082171990011", "Jl. Tuanku Tambusai No. 45, Pekanbaru", "2 pesanan", ""},
            {"farel", "farel@email.com", "081276543210", "Jl. Sisingamangaraja No. 3, Pekanbaru", "2 pesanan", ""},
            {"faris", "faris@email.com", "085766554433", "Jl. HR Soebrantas Km 12, Pekanbaru", "2 pesanan", ""},
            {"ilyas", "ilyas@email.com", "082345678901", "Jl. Merdeka No. 5, Pekanbaru", "4 pesanan", ""},
            {"islam", "islam@email.com", "085211223344", "Jl. Soekarno-Hatta No. 77, Pekanbaru", "3 pesanan", ""},
            {"reno", "reno@email.com", "08126317432", "-", "0 pesanan", ""},
            {"Rina", "rina@email.com", "083456789012", "Jl. Sudirman No. 12, Pekanbaru", "2 pesanan", ""},
            {"Salwa", "salwa@email.com", "081234567890", "Jl. Contoh No. 10, Pekanbaru", "4 pesanan", ""}
        };

        DefaultTableModel model = new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5; // Hanya kolom Aksi yang dapat diklik
            }
        };

        JTable table = new JTable(model);
        table.setRowHeight(42);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.getTableHeader().setBackground(Color.WHITE);
        table.getTableHeader().setPreferredSize(new Dimension(0, 40));
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setGridColor(new Color(222, 226, 230));
        table.setSelectionBackground(new Color(240, 244, 248));

        // Render khusus untuk Tombol Aksi (Edit & Hapus)
        table.getColumnModel().getColumn(5).setCellRenderer(new ActionButtonRenderer());

        JScrollPane tableScrollPane = new JScrollPane(table);
        tableScrollPane.setBackground(Color.WHITE);
        tableScrollPane.setBorder(BorderFactory.createLineBorder(new Color(222, 226, 230)));

        JPanel centerContainer = new JPanel(new BorderLayout());
        centerContainer.setBackground(new Color(248, 249, 250));
        centerContainer.add(spacePanel, BorderLayout.NORTH);
        centerContainer.add(tableScrollPane, BorderLayout.CENTER);

        content.add(centerContainer, BorderLayout.CENTER);
        return content;
    }

    // Custom Cell Renderer untuk menampilkan Tombol Edit & Hapus di dalam Tabel
    static class ActionButtonRenderer extends JPanel implements TableCellRenderer {
        private final JButton btnEdit = new JButton("Edit");
        private final JButton btnHapus = new JButton("Hapus");

        public ActionButtonRenderer() {
            setLayout(new FlowLayout(FlowLayout.RIGHT, 6, 6));
            setBackground(Color.WHITE);

            btnEdit.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            btnEdit.setForeground(Color.WHITE);
            btnEdit.setBackground(new Color(13, 110, 253));
            btnEdit.setFocusPainted(false);

            btnHapus.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            btnHapus.setForeground(new Color(220, 53, 69));
            btnHapus.setBackground(Color.WHITE);
            btnHapus.setBorder(BorderFactory.createLineBorder(new Color(220, 53, 69)));
            btnHapus.setFocusPainted(false);

            add(btnEdit);
            add(btnHapus);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (isSelected) {
                setBackground(table.getSelectionBackground());
            } else {
                setBackground(Color.WHITE);
            }
            return this;
        }
    }

    private JPanel createFooterPanel() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footer.setBackground(Color.WHITE);
        footer.setBorder(new EmptyBorder(12, 0, 12, 0));
        
        JLabel lblFooter = new JLabel("© 2026 LaundryKita — Sistem Pemesanan Laundry");
        lblFooter.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFooter.setForeground(new Color(108, 117, 125));
        footer.add(lblFooter);

        return footer;
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new LaundryAdmin().setVisible(true));
    }
}