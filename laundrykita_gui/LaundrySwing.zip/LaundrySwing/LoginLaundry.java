
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import java.awt.Color;
import java.awt.Font;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

public class LoginLaundry extends JFrame {

    private JTextField inputEmail;
    private JPasswordField inputPassword;
    private JLabel pesan;
    private JButton tombolLogin;

    private final Color biru = new Color(21, 87, 176);
    private final Color kuning = new Color(240, 201, 40);
    private final Color latar = new Color(245, 248, 252);

    public LoginLaundry() {
        setTitle("Login - LaundryKita");
        setSize(480, 590);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel utama = new JPanel(new GridBagLayout());
        utama.setBackground(latar);
        utama.setBorder(BorderFactory.createEmptyBorder(
            20, 25, 20, 25
        ));

        JPanel kartu = new JPanel(new BorderLayout(0, 20));
        kartu.setBackground(Color.WHITE);
        kartu.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(
                new Color(229, 233, 239)
            ),
            BorderFactory.createEmptyBorder(
                30, 30, 30, 30
            )
        ));

        kartu.setPreferredSize(new Dimension(390, 490));

        // Bagian logo dan judul
        JPanel header = new JPanel();
        header.setBackground(Color.WHITE);
        header.setLayout(new javax.swing.BoxLayout(
            header, javax.swing.BoxLayout.Y_AXIS
        ));

        JLabel logo = new JLabel("🧺");
        logo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 55));
        logo.setAlignmentX(CENTER_ALIGNMENT);

        JLabel judul = new JLabel("LaundryKita");
        judul.setFont(new Font("Arial", Font.BOLD, 27));
        judul.setForeground(biru);
        judul.setAlignmentX(CENTER_ALIGNMENT);

        JLabel subjudul = new JLabel(
            "Sistem Pemesanan Laundry"
        );
        subjudul.setFont(new Font("Arial", Font.PLAIN, 14));
        subjudul.setForeground(Color.GRAY);
        subjudul.setAlignmentX(CENTER_ALIGNMENT);

        header.add(logo);
        header.add(judul);
        header.add(javax.swing.Box.createVerticalStrut(8));
        header.add(subjudul);

        // Bagian form login
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);

        JLabel labelEmail = new JLabel("Email");
        labelEmail.setFont(new Font("Arial", Font.BOLD, 14));

        inputEmail = new JTextField();
        inputEmail.setFont(new Font("Arial", Font.PLAIN, 14));
        inputEmail.setPreferredSize(new Dimension(300, 38));
        inputEmail.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(
                new Color(213, 220, 229)
            ),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));

        JLabel labelPassword = new JLabel("Password");
        labelPassword.setFont(new Font("Arial", Font.BOLD, 14));

        inputPassword = new JPasswordField();
        inputPassword.setFont(new Font("Arial", Font.PLAIN, 14));
        inputPassword.setPreferredSize(new Dimension(300, 38));
        inputPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(
                new Color(213, 220, 229)
            ),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));

        pesan = new JLabel(" ");
        pesan.setForeground(Color.RED);
        pesan.setFont(new Font("Arial", Font.PLAIN, 12));

        tombolLogin = new JButton("Login");
        tombolLogin.setFont(new Font("Arial", Font.BOLD, 15));
        tombolLogin.setForeground(Color.WHITE);
        tombolLogin.setBackground(biru);
        tombolLogin.setFocusPainted(false);
        tombolLogin.setPreferredSize(new Dimension(300, 42));
        tombolLogin.setBorderPainted(false);
        tombolLogin.setOpaque(true);

        gbc.gridy = 0;
        form.add(labelEmail, gbc);

        gbc.gridy = 1;
        form.add(inputEmail, gbc);

        gbc.gridy = 2;
        form.add(labelPassword, gbc);

        gbc.gridy = 3;
        form.add(inputPassword, gbc);

        gbc.gridy = 4;
        form.add(pesan, gbc);

        gbc.gridy = 5;
        gbc.insets = new Insets(12, 0, 0, 0);
        form.add(tombolLogin, gbc);

        // Garis kuning sebagai aksen LaundryKita
        JPanel garisKuning = new JPanel();
        garisKuning.setBackground(kuning);
        garisKuning.setPreferredSize(new Dimension(300, 4));

        kartu.add(header, BorderLayout.NORTH);
        kartu.add(form, BorderLayout.CENTER);
        kartu.add(garisKuning, BorderLayout.SOUTH);

        utama.add(kartu);
        add(utama);

        // Event ketika tombol Login diklik
        tombolLogin.addActionListener(e -> prosesLogin());

        inputPassword.addActionListener(e -> prosesLogin());
    }

    private void prosesLogin() {
        String email = inputEmail.getText().trim();
        String password = new String(
            inputPassword.getPassword()
        );

        if (email.isEmpty() || password.isEmpty()) {
            pesan.setText(
                "Email dan password wajib diisi."
            );
            return;
        }

        if (email.equalsIgnoreCase("admin@laundrykita.com")
                && password.equals("admin123")) {
            JOptionPane.showMessageDialog(
                this,
                "Halaman admin tidak termasuk dalam dua halaman tugas ini."
            );
            return;
        }

        ProfilCustomer profil = new ProfilCustomer();
        profil.setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginLaundry
         login = new LoginLaundry
        ();
            login.setVisible(true);
        });
    }
}
