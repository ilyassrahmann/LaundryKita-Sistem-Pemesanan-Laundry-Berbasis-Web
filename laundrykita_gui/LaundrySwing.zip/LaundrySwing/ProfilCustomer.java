
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Dimension;

public class ProfilCustomer extends JFrame {

    private JTextField inputNama;
    private JTextField inputEmail;
    private JTextField inputTelepon;
    private JTextField inputAlamat;

    private final Color biru = new Color(21, 87, 176);
    private final Color kuning = new Color(240, 201, 40);
    private final Color latar = new Color(245, 248, 252);

    public ProfilCustomer() {
        setTitle("Profil Saya - LaundryKita");
        setSize(650, 570);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel utama = new JPanel(new BorderLayout(0, 18));
        utama.setBackground(latar);
        utama.setBorder(
            BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        // Header halaman
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(biru);
        header.setBorder(
            BorderFactory.createEmptyBorder(15, 20, 15, 20)
        );

        JLabel judul = new JLabel("LaundryKita");
        judul.setFont(new Font("Arial", Font.BOLD, 24));
        judul.setForeground(Color.WHITE);

        JLabel subjudul = new JLabel("Profil Saya");
        subjudul.setFont(new Font("Arial", Font.PLAIN, 14));
        subjudul.setForeground(Color.WHITE);

        JPanel teksHeader = new JPanel();
        teksHeader.setBackground(biru);
        teksHeader.setLayout(
            new javax.swing.BoxLayout(
                teksHeader, javax.swing.BoxLayout.Y_AXIS
            )
        );
        teksHeader.add(judul);
        teksHeader.add(subjudul);

        header.add(teksHeader, BorderLayout.WEST);

        // Kartu profil
        JPanel kartu = new JPanel(new BorderLayout(0, 18));
        kartu.setBackground(Color.WHITE);
        kartu.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(
                new Color(229, 233, 239)
            ),
            BorderFactory.createEmptyBorder(22, 25, 22, 25)
        ));

        // Informasi customer
        JPanel identitas = new JPanel();
        identitas.setBackground(Color.WHITE);
        identitas.setLayout(
            new javax.swing.BoxLayout(
                identitas, javax.swing.BoxLayout.Y_AXIS
            )
        );

        JLabel avatar = new JLabel("👤");
        avatar.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 40));
        avatar.setAlignmentX(CENTER_ALIGNMENT);

        JLabel namaCustomer = new JLabel("Salwachika Deri");
        namaCustomer.setFont(new Font("Arial", Font.BOLD, 20));
        namaCustomer.setForeground(biru);
        namaCustomer.setAlignmentX(CENTER_ALIGNMENT);

        JLabel statusCustomer = new JLabel(
            "Customer LaundryKita"
        );
        statusCustomer.setFont(
            new Font("Arial", Font.PLAIN, 13)
        );
        statusCustomer.setForeground(Color.GRAY);
        statusCustomer.setAlignmentX(CENTER_ALIGNMENT);

        identitas.add(avatar);
        identitas.add(namaCustomer);
        identitas.add(statusCustomer);

        // Form data profil
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 5, 7, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel labelNama = new JLabel("Nama Lengkap");
        JLabel labelEmail = new JLabel("Email");
        JLabel labelTelepon = new JLabel("Nomor HP");
        JLabel labelAlamat = new JLabel("Alamat");

        inputNama = buatInput("Salwachika Deri");
        inputEmail = buatInput("customer@gmail.com");
        inputTelepon = buatInput("");
        inputAlamat = buatInput("");

        tambahBaris(form, gbc, 0, labelNama, inputNama);
        tambahBaris(form, gbc, 1, labelEmail, inputEmail);
        tambahBaris(form, gbc, 2, labelTelepon, inputTelepon);
        tambahBaris(form, gbc, 3, labelAlamat, inputAlamat);

        // Tombol
        JPanel tombolPanel = new JPanel();
        tombolPanel.setBackground(Color.WHITE);

        JButton tombolSimpan = new JButton("Simpan Perubahan");
        tombolSimpan.setBackground(biru);
        tombolSimpan.setForeground(Color.WHITE);
        tombolSimpan.setFocusPainted(false);
        tombolSimpan.setOpaque(true);
        tombolSimpan.setBorderPainted(false);

        JButton tombolKeluar = new JButton("Keluar");
        tombolKeluar.setBackground(kuning);
        tombolKeluar.setForeground(Color.BLACK);
        tombolKeluar.setFocusPainted(false);
        tombolKeluar.setOpaque(true);
        tombolKeluar.setBorderPainted(false);

        tombolPanel.add(tombolSimpan);
        tombolPanel.add(tombolKeluar);

        kartu.add(identitas, BorderLayout.NORTH);
        kartu.add(form, BorderLayout.CENTER);
        kartu.add(tombolPanel, BorderLayout.SOUTH);

        // Navigasi bawah
        JPanel navigasi = new JPanel();
        navigasi.setBackground(Color.WHITE);
        navigasi.setBorder(BorderFactory.createMatteBorder(
            1, 0, 0, 0, new Color(229, 233, 239)
        ));

        JLabel menu = new JLabel(
            "Beranda     |     Pesanan Saya     |     Profil"
        );
        menu.setFont(new Font("Arial", Font.PLAIN, 13));
        menu.setForeground(biru);

        navigasi.add(menu);

        utama.add(header, BorderLayout.NORTH);
        utama.add(kartu, BorderLayout.CENTER);
        utama.add(navigasi, BorderLayout.SOUTH);

        add(utama);

        // Event simpan profil
        tombolSimpan.addActionListener(e -> {
            if (inputNama.getText().trim().isEmpty()
                    || inputEmail.getText().trim().isEmpty()
                    || inputTelepon.getText().trim().isEmpty()
                    || inputAlamat.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(
                    this,
                    "Semua data profil harus diisi.",
                    "Peringatan",
                    JOptionPane.WARNING_MESSAGE
                );

            } else {
                namaCustomer.setText(inputNama.getText().trim());

                JOptionPane.showMessageDialog(
                    this,
                    "Perubahan profil berhasil disimpan."
                );
            }
        });

        // Kembali ke halaman login
        tombolKeluar.addActionListener(e -> {
            int pilihan = JOptionPane.showConfirmDialog(
                this,
                "Apakah kamu yakin ingin keluar?",
                "Konfirmasi Keluar",
                JOptionPane.YES_NO_OPTION
            );

            if (pilihan == JOptionPane.YES_OPTION) {
                LoginLaundry login =
                    new LoginLaundry();
                login.setVisible(true);
                dispose();
            }
        });
    }

    private JTextField buatInput(String teks) {
        JTextField input = new JTextField(teks, 20);
        input.setFont(new Font("Arial", Font.PLAIN, 13));
        input.setPreferredSize(new Dimension(300, 34));
        input.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(
                new Color(213, 220, 229)
            ),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        return input;
    }

    private void tambahBaris(
            JPanel panel,
            GridBagConstraints gbc,
            int baris,
            JLabel label,
            JTextField input) {

        label.setFont(new Font("Arial", Font.BOLD, 13));

        gbc.gridx = 0;
        gbc.gridy = baris;
        gbc.weightx = 0.3;
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 0.7;
        panel.add(input, gbc);
    }
}
